#!/usr/bin/env python3
"""DocSync command-line Kanban and shared organizer entry point."""
import docsync_purchase as PURCHASE
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
import docsync_intake
from docsync_core import ROOT, WIP, STAGES, LABELS, board, health
from docsync_paths import workspace_paths

def main(argv=None):
    paths = workspace_paths()
    configured_root = Path(paths['DOCSYNC_ROOT'])
    parser = argparse.ArgumentParser(description='DocSync: scan → board → review → preview → apply → verify')
    parser.add_argument('--root', '--year-root', dest='year_root', type=Path, default=configured_root,
                        help='WIP & Reference root (--year-root remains an alias)')
    sub = parser.add_subparsers(dest='command')
    for name in ('board', 'status'):
        p = sub.add_parser(name)
        p.add_argument('--json', action='store_true')
        if name == 'board':
            p.add_argument('--stage', choices=STAGES)
            p.add_argument('--limit', type=int, default=8, help='cards per column; 0 shows all')
    sub.add_parser('scan')
    rules = sub.add_parser('rules', help='view, export or update folder classification settings')
    rule_action = rules.add_mutually_exclusive_group()
    rule_action.add_argument('--export', action='store_true', help='print editable JSON')
    rule_action.add_argument('--import', dest='rule_input', help='save JSON from a file or - for stdin')
    sub.add_parser('preview')
    apply = sub.add_parser('apply')
    apply.add_argument('--sync-project', action='store_true', help='also run external rclone sync')
    review = sub.add_parser('review')
    review.add_argument('dossier')
    review.add_argument('category')
    review.add_argument('--note', default='')
    review.add_argument('--status', choices=('in_progress', 'waiting_external', 'approved'), default='in_progress')
    state = sub.add_parser('set-status')
    state.add_argument('dossier')
    state.add_argument('status', choices=WIP.VALID_STATUSES)
    docsync_intake.register(sub.add_parser('intake', help='xem trước hoặc gửi file đến ERP/EIM'))
    args = parser.parse_args(argv)
    if args.command == 'intake':
        return docsync_intake.execute(args)
    root = args.year_root.resolve()
    command = args.command or 'board'
    if command in ('preview', 'apply'):
        if root != configured_root.resolve():
            parser.error('preview/apply only support the configured WIP & Reference root')
        flags = ['--plan-managed-rules'] if command == 'preview' else ['--apply-managed-rules']
        if command == 'preview' or not args.sync_project:
            flags.append('--no-sync')
        result = subprocess.run(['/bin/sh', str(ROOT / 'ivar-documents-organizer.sh'), *flags],
                                env={**os.environ, **paths})
        if result.returncode:
            return result.returncode
        WIP.scan(root, [], True)
        WIP.dashboard(root)
        print('Next: docsync board')
    elif command == 'rules':
        if args.rule_input:
            raw = sys.stdin.read(262145) if args.rule_input == '-' else Path(args.rule_input).read_text(encoding='utf-8')
            if len(raw.encode()) > 262144:
                raise ValueError('File quy tắc vượt giới hạn 256 KiB.')
            WIP.save_rules(root, json.loads(raw))
            print(f'Đã lưu quy tắc tại {WIP.rules_path(root)}.')
            return 0
        rules = WIP.load_rules(root)
        if args.export:
            print(json.dumps(rules, ensure_ascii=False, indent=2))
            return 0
        for rule in rules['categories']:
            mode = rule.get('route_mode') or 'topic_auto'
            print(f"{rule['id']}: {rule['label']} | {mode if rule.get('enabled', True) else 'disabled'} → {rule['target']}")
        print(f'{PURCHASE.RULE}: {PURCHASE.RULE_DESCRIPTION} | managed_move | {PURCHASE.purchase_root()}')
        print('Next: docsync review <dossier> <category> --note <reason>')
    elif command == 'scan':
        print(json.dumps(WIP.scan(root, [], True), ensure_ascii=False))
        WIP.dashboard(root)
        print('Next: docsync board → docsync review <dossier> <category>')
    elif command == 'review':
        WIP.review_dossier(root, args.dossier, args.category, None, args.status, args.note)
        WIP.dashboard(root)
        print('Review recorded. Review-only categories require manual filing. Next: docsync board')
    elif command == 'set-status':
        WIP.set_dossier_status(root, args.dossier, args.status)
        WIP.dashboard(root)
        print('Status recorded. Next: docsync board')
    else:
        data = health(root) if command == 'status' else board(root)
        if command == 'board' and getattr(args, 'stage', None):
            data['cards'] = [card for card in data['cards'] if card['stage'] == args.stage]
        if getattr(args, 'json', False):
            print(json.dumps(data, ensure_ascii=False, indent=2))
        elif command == 'status':
            print("Organizer: " + ("running" if data["organizerBusy"] else "idle"))
            for unit, values in data['services'].items():
                print(f"{unit}: {values.get('ActiveState', 'unknown')}/{values.get('SubState', '?')} result={values.get('Result', '—')}")
            print(f"Last timer completion: {data['lastTimerRun'] or 'unknown'} | Next: {data['nextRun'] or 'unknown'}")
            print('\n'.join(data['recentLogs'][-12:]))
            print('Next: docsync board → docsync preview')
        else:
            print('DocSync Kanban · ' + ' → '.join(f"{LABELS[k]}: {data['counts'][k]}" for k in STAGES))
            for stage in STAGES:
                if getattr(args, 'stage', None) and args.stage != stage:
                    continue
                print(f"\n{LABELS[stage]} ({data['counts'][stage]})")
                cards = [c for c in data['cards'] if c['stage'] == stage]
                limit = max(0, getattr(args, 'limit', 8))
                shown = cards[:limit] if limit else cards
                for card in shown:
                    # Escape terminal control characters in untrusted file names/reasons.
                    clean = lambda v: str(v).encode('unicode_escape').decode() if any(ord(c) < 32 or ord(c) == 127 for c in str(v)) else str(v)
                    print(f"  • {clean(card['path'])} [{card['category']}]")
                    print(f"    {clean(card['reason'])} → {clean(card['target'] or 'Chưa có đích')}")
                    print(f"    {card['next']} | dossier: {clean(card['dossier'] or 'chạy docsync scan')}")
                if len(shown) < len(cards):
                    print(f'  … {len(cards)-len(shown)} more; docsync board --stage {stage} --limit 0')
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, WIP.sqlite3.Error) as error:
        print(f'DocSync error: {error}', file=sys.stderr)
        raise SystemExit(1)
