#!/usr/bin/env python3
"""Read-only first WIP indexing and Kanban reporting for WIP & Reference.

This tool deliberately has no move, delete, or filing command.  It records
classification proposals in SQLite and renders a local, static dashboard so a
person can approve a dossier before any future filing automation is enabled.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import fcntl
import hashlib
import html
import json
import os
import tempfile
import re
import sqlite3
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
import sys
from collections import Counter
from pathlib import Path
from typing import Iterable
from docsync_paths import state_directory, work_root
from docsync_layout import (CATEGORY_TARGETS, REPORT_TARGETS, DIRECTORIES, SCOPES, LEGACY_SCOPES,
                            OLD_TARGETS, FOLDER_CATEGORIES, B2B_PRICES, B2B_RECONCILIATION,
                            within, approved_target, safe_directory)


TOOL_ROOT = Path(__file__).resolve().parent
DOCUMENTS_ROOT = TOOL_ROOT.parent
YEAR_ROOT = work_root()
STATE_DIR_NAME = ".wip"
DEFAULT_SCOPES = (*SCOPES, *LEGACY_SCOPES)
WIP_DIRECTORIES = DIRECTORIES
VALID_STATUSES = ("captured", "auto_classified", "needs_review", "in_progress", "waiting_external", "approved", "filed", "archived")

DEFAULT_RULES = {
    "version": 10,
    "excluded_paths": [
        "03/Adults/**", "03/Kids/**", "03/Tram Nam Co Don/**",
        "2026/2026-03/Adults/**", "2026/2026-03/Kids/**", "2026/2026-03/Tram Nam Co Don/**", "tieng goi noi hoang da - Jack London/**",
        ".wip/**", ".docsync/**", "00_INBOX/.*/**",
    ],
    "generated_name_patterns": [r"^pdftohtml", r"^pdftotext", r"^text\.txt$", r"^agents\.md$"],
    "categories": [
        {"id": "vat", "label": "VAT", "confidence": 0.98,
         "patterns": [r"iv-(?:mtt|company)-batch"],
         "target": "AT. VAT", "route_mode": "managed_move"},
        {"id": "shopee_reports", "label": "Shopee reports", "confidence": 0.96,
         "patterns": [r"(?:^|/)at\. ?shopee reports(?:/|$)", r"(?:^|/)order\.", r"(?:^|/)orders_\d{4}-\d{2}-\d{2}_\d{4}-\d{2}-\d{2}\.xlsx$"],
         "target": "AT. Shopee reports", "route_mode": "managed_move"},
        {"id": "ghtk_reports", "label": "GHTK reports", "confidence": 0.97,
         "patterns": [r"(?:^|/)at\. ?ghtk reports(?:/|$)", r"ghtk_", r"bien_ban_doi_soat"],
         "target": "AT. GHTK reports", "route_mode": "managed_move"},
        {"id": "bank_statements", "label": "SAOKE", "confidence": 0.98,
         "patterns": [r"sao ?ke", r"(?:^|/)(?:danh sach giao dich|lich-su-giao-dich).*\.xlsx?$"] ,
         "target": "AT. SAOKE", "route_mode": "managed_move"},
        {"id": "finance_ops", "label": "Finance & Operations", "confidence": 0.94,
         "patterns": [r"(?:^|/)(?:wip ke toan thue|acb saoke)(?:/|$)", r"c[oô]ng n[oợ]", r"chi[_ -]?tiet[_ -]?cong[_ -]?no", r"sao ?ke", r"so_tien_gui", r"h[oó]a[- ]?d[oơ]n", r"invoice", r"\bunc\b"],
         "target": "IVAR/Accounting - Ke toan/Data - Du lieu"},
        {"id": "quality_regulatory", "label": "Quality & Regulatory", "confidence": 0.93,
         "patterns": [r"(?:^|/)at\. ?qc reports(?:/|$)", r"tự công bố", r"ho so danh gia cuc", r"\bcoa\b", r"\bqcvn\b", r"attp", r"ki[eể]m nghi[eệ]m", r"ssop", r"chứng nh[aậ]n", r"c[oô]ng b[oố]"],
         "target": "IVAR/QC - Quan ly chat luong"},
        {"id": "packaging", "label": "Packaging & Product Artwork", "confidence": 0.92,
         "patterns": [r"review label", r"\blabel\b", r"sachet", r"\bbox\b", r"bao b[iì]", r"in an"],
         "target": "IVAR/Manufacturing - San xuat/In an"},
        {"id": "commerce", "label": "Commerce & Sales", "confidence": 0.90,
         "patterns": [r"b2b", r"shopee", r"b[aả]ng gi[aá]", r"ch[ưu]ơ?ng tr[iì]nh.*(?:khuy[eế]n m[aã]i|b[aá]n h[aà]ng|d[aạ]i l[yý])", r"thong bao.*(?:gia|dai ly|ban hang)", r"shop-stats", r"mass_upload"],
         "target": "IVAR/Marketing-Sales-CS"},
        {"id": "legal_corporate", "label": "Legal & Corporate", "confidence": 0.88,
         "patterns": [r"h[oợ]p d[oồ]ng", r"u[yỷ][ _-]?quy[eề]n", r"dkkd", r"bhxh", r"v[ăa]n ph[oò]ng", r"sepay", r"vietnam bank", r"vietinbank"],
         "target": "IVAR/Legal - Phap ly"},
        {"id": "sourcing_logistics", "label": "Sourcing & Logistics", "confidence": 0.94,
         "patterns": [r"(?:^|/)at\. ?sourcing contracts(?:/|$)", r"^hbl-", r"bill of lading", r"packing list", r"v[aậ]n đơn"],
         "target": "IVAR/Sourcing - Nhap hang/Logistics"},
        {"id": "technical", "label": "Technical / Quarantine", "confidence": 0.97,
         "patterns": [r"\.(?:log|deb|dmg|tar\.gz)$", r"^log\.", r"(?:^|/)(?:plugin codes|code)(?:/|$)", r"^new\.html$"],
         "target": "2026/91_TECH_QUARANTINE"},
    ],
}

for _category in DEFAULT_RULES["categories"]:
    _category["target"] = CATEGORY_TARGETS[_category["id"]]

DEFAULT_RULES['categories'].extend([
    {'id': 'production', 'label': 'Sản xuất', 'confidence': 0.96,
     'patterns': [r'l[eệ]nh s[aả]n xu[aấ]t', r'k[eế] ho[aạ]ch s[aả]n xu[aấ]t', r'production (?:order|plan)'],
     'target': CATEGORY_TARGETS['production']},
    {'id': 'purchasing', 'label': 'Mua hàng - dịch vụ', 'confidence': 0.96,
     'patterns': [r'(?:^|/)at\. ?sourcing contracts(?:/|$)', r'tokhaihq', r't[oờ] khai h[aả]i quan', r'purchase order'],
     'target': CATEGORY_TARGETS['purchasing']},
])
# Known defaults only: migrate these patterns without broadening custom rules.
TOPIC_PATTERNS = {
    'shopee_reports': [r'shopee.*(?:v[aậ]n đ[oơ]n|shipping|giao h[aà]ng|logistics)'],
    'finance_ops': [r'b[aả]ng n[oộ]p thu[eế]', r'(?:đ[eề]|de) ngh[iị] thanh to[aá]n', r'\bdebit note\b'],
    'quality_regulatory': [r'^specs?\b', r'\btechnical specification\b', r'^tcb[-_ ]'],
}
for _category in DEFAULT_RULES['categories']:
    _category['patterns'].extend(TOPIC_PATTERNS.get(_category['id'], []))
    if _category['id'] == 'sourcing_logistics':
        _category['patterns'].remove(r'(?:^|/)at\. ?sourcing contracts(?:/|$)')


MANAGED_TARGETS = {
    "vat": ("AT.VAT", "AT. VAT"),
    "shopee_reports": ("AT.Shopee reports", "AT. Shopee reports"),
    "ghtk_reports": ("AT.GHTK reports", "AT. GHTK reports"),
}


def migrate_rules(rules: dict) -> tuple[dict, bool]:
    """Upgrade only known defaults without overwriting user-defined rules."""
    migrated = copy.deepcopy(rules)
    changed = False
    categories = migrated.get("categories")
    if not isinstance(categories, list):
        return migrated, changed

    legacy_patterns = {
        r"(?:^|/)at\.shopee reports(?:/|$)": r"(?:^|/)at\. ?shopee reports(?:/|$)",
        r"(?:^|/)at\.ghtk reports(?:/|$)": r"(?:^|/)at\. ?ghtk reports(?:/|$)",
        r"(?:^|/)at\.qc reports(?:/|$)": r"(?:^|/)at\. ?qc reports(?:/|$)",
        r"(?:^|/)at\.sourcing contracts(?:/|$)": r"(?:^|/)at\. ?sourcing contracts(?:/|$)",
    }
    known_ids = {category.get("id") for category in categories if isinstance(category, dict)}
    for category in categories:
        if not isinstance(category, dict):
            continue
        target_pair = MANAGED_TARGETS.get(category.get("id"))
        if target_pair and category.get("target") == target_pair[0]:
            category["target"] = target_pair[1]
            changed = True
        patterns = category.get("patterns")
        if isinstance(patterns, list):
            updated_patterns = [legacy_patterns.get(pattern, pattern) for pattern in patterns]
            if updated_patterns != patterns:
                category["patterns"] = updated_patterns
                changed = True

    if "bank_statements" not in known_ids:
        bank_rule = next(item for item in DEFAULT_RULES["categories"] if item["id"] == "bank_statements")
        insert_at = next((index for index, item in enumerate(categories) if item.get("id") == "finance_ops"), len(categories))
        categories.insert(insert_at, copy.deepcopy(bank_rule))
        changed = True
    if migrated.get("version", 0) < 8:
        replacements = {
            r"iv-mtt-batch": r"iv-(?:mtt|company)-batch",
            r"ch[ưu]ơ?ng tr[iì]nh": r"ch[ưu]ơ?ng tr[iì]nh.*(?:khuy[eế]n m[aã]i|b[aá]n h[aà]ng|d[aạ]i l[yý])",
            r"thong bao": r"thong bao.*(?:gia|dai ly|ban hang)",
        }
        defaults = {item["id"]: item for item in DEFAULT_RULES["categories"]}
        for category in categories:
            patterns = category.get("patterns", [])
            # Migrate known patterns only; preserve custom destinations/modes.
            category["patterns"] = [replacements.get(pattern, pattern) for pattern in patterns]
            if category.get("id") in {"shopee_reports", "bank_statements"}:
                extra = defaults[category["id"]]["patterns"][-1]
                if extra not in category["patterns"]:
                    category["patterns"].append(extra)
        migrated["version"] = 8
        changed = True
    for category in categories:
        category_id = category.get("id")
        if category.get("target") in OLD_TARGETS.get(category_id, ()):
            category["target"] = CATEGORY_TARGETS[category_id]
            changed = True
    if migrated.get("version", 0) < 9:
        migrated["version"] = 9
        changed = True
    if migrated.get('version', 0) < 10:
        for default in DEFAULT_RULES['categories']:
            if default['id'] not in known_ids and default['id'] in ('production', 'purchasing'):
                categories.append(copy.deepcopy(default))
            else:
                for category in categories:
                    if category.get('id') == default['id']:
                        if default['id'] == 'shopee_reports':
                            category['patterns'] = [r'(?:^|/)order\.' if p == r'order\.' else p for p in category.get('patterns', [])]
                        for pattern in TOPIC_PATTERNS.get(default['id'], []):
                            if pattern not in category.get('patterns', []):
                                category.setdefault('patterns', []).append(pattern)
                        if default['id'] == 'sourcing_logistics':
                            category['patterns'] = [p for p in category.get('patterns', []) if p != r'(?:^|/)at\. ?sourcing contracts(?:/|$)']
        if '.docsync/**' not in migrated.get('excluded_paths', []):
            migrated.setdefault('excluded_paths', []).append('.docsync/**')
        migrated['version'] = 10
        changed = True
    return migrated, changed


def state_dir(year_root: Path) -> Path:
    return year_root / STATE_DIR_NAME


def db_path(year_root: Path) -> Path:
    return state_dir(year_root) / "index.sqlite"


def rules_path(year_root: Path) -> Path:
    return state_dir(year_root) / "rules.json"


def ensure_state(year_root: Path) -> tuple[Path, Path]:
    state = state_dir(year_root)
    state.mkdir(parents=True, exist_ok=True)
    directories = [safe_directory(year_root, name) for name in WIP_DIRECTORIES]
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
    rule_file = rules_path(year_root)
    if not rule_file.exists():
        rule_file.write_text(json.dumps(DEFAULT_RULES, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    else:
        load_rules(year_root)
    return db_path(year_root), rule_file


def open_db(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS documents (
            path TEXT PRIMARY KEY,
            sha256 TEXT NOT NULL,
            byte_size INTEGER NOT NULL,
            modified_at INTEGER NOT NULL,
            observed_at TEXT NOT NULL,
            category TEXT NOT NULL,
            confidence REAL NOT NULL,
            classification_reason TEXT NOT NULL,
            proposed_target TEXT,
            dossier_id TEXT NOT NULL,
            status TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        );
        CREATE INDEX IF NOT EXISTS idx_documents_dossier ON documents(dossier_id);
        CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
        CREATE TABLE IF NOT EXISTS dossiers (
            dossier_id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            status TEXT NOT NULL,
            proposed_target TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            event_type TEXT NOT NULL,
            subject TEXT NOT NULL,
            detail TEXT NOT NULL
        );
        """
    )
    return conn


def digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


def normalized(value: str) -> str:
    return unicodedata.normalize("NFC", value).replace("đ", "d").replace("Đ", "D").casefold()


def load_rules(root: Path) -> dict:
    """Read effective rules without writing or initializing a workspace."""
    path = rules_path(root)
    return migrate_rules(json.loads(path.read_text(encoding='utf-8')))[0] if path.exists() else copy.deepcopy(DEFAULT_RULES)


def rules_revision(rules):
    return hashlib.sha256(json.dumps(rules, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def validate_rules(root, rules):
    """Check rule fields and automatic destinations before saving."""
    if not isinstance(rules, dict) or rules.get('version') != DEFAULT_RULES['version']:
        raise ValueError('Dùng bản JSON xuất từ DocSync để chỉnh quy tắc.')

    def strings(items, name, regex=False):
        if (not isinstance(items, list) or len(items) > 60
                or any(not isinstance(item, str) or not item.strip() or len(item) > 400
                       or any(ord(char) < 32 for char in item) for item in items)):
            raise ValueError(f'{name}: nhập tối đa 60 mẫu, mỗi mẫu dài tối đa 400 ký tự.')
        if regex:
            for item in items:
                try:
                    re.compile(item, re.I)
                except (re.error, OverflowError, RecursionError) as error:
                    raise ValueError(f'{name}: regex không hợp lệ ({error}).') from error

    strings(rules.get('excluded_paths'), 'Thư mục bỏ qua')
    strings(rules.get('generated_name_patterns'), 'File tự sinh', regex=True)
    categories = rules.get('categories')
    if not isinstance(categories, list) or len(categories) > 80:
        raise ValueError('Cần một danh sách tối đa 80 quy tắc.')
    ids = set()
    for item in categories:
        category = item.get('id') if isinstance(item, dict) else None
        if not isinstance(category, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,39}', category) or category in ids:
            raise ValueError('Mã quy tắc phải duy nhất, bắt đầu bằng chữ thường và chỉ dùng a-z, 0-9 hoặc _.')
        ids.add(category)
        label, target = item.get('label'), item.get('target')
        if (not isinstance(label, str) or not label.strip() or len(label) > 120
                or any(ord(char) < 32 for char in label)):
            raise ValueError(f'{category}: tên nhóm không hợp lệ.')
        if (not isinstance(target, str) or not target.strip() or len(target) > 300
                or any(ord(char) < 32 for char in target) or Path(target).as_posix() != target
                or Path(target).is_absolute() or '..' in Path(target).parts or target == '.'):
            raise ValueError(f'{category}: đích phải là thư mục tương đối trong WIP.')
        confidence = item.get('confidence')
        if type(confidence) not in (float, int) or not 0 <= confidence <= 1:
            raise ValueError(f'{category}: độ tin cậy phải từ 0 đến 1.')
        strings(item.get('patterns'), category, regex=True)
        if type(item.get('enabled', True)) is not bool:
            raise ValueError(f'{category}: enabled phải là true hoặc false.')
        mode = item.get('route_mode')
        if mode not in (None, 'review_only', 'managed_move', 'topic_auto'):
            raise ValueError(f'{category}: chế độ di chuyển không hợp lệ.')
        if category == 'ghtk_reports' and target != REPORT_TARGETS[category]:
            raise ValueError(f'{category}: dùng đích {REPORT_TARGETS[category]} để watcher EIM tìm thấy file.')
        if mode in ('managed_move', 'topic_auto') and not approved_target(root, target, configured=True):
            raise ValueError(f'{category}: đích tự động phải nằm trong một nhóm công việc và không đi qua liên kết mềm.')
    if 'bank_statements' not in ids:
        raise ValueError('Giữ quy tắc bank_statements trong danh sách và tắt bằng enabled: false nếu cần.')


class RulesConflict(ValueError):
    """Another editor saved a newer revision."""


def save_rules(root: Path, rules, revision=None):
    """Save a revision atomically under the organizer lock."""
    if not root.is_dir():
        raise ValueError('Thư mục WIP không tồn tại.')
    state = state_directory()
    state.mkdir(parents=True, exist_ok=True)
    with (state / 'organizer.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if revision is not None and revision != rules_revision(load_rules(root)):
            raise RulesConflict('Quy tắc vừa thay đổi. Tải lại trước khi lưu.')
        validate_rules(root, rules)
        path = safe_directory(root, '.wip/rules.json')
        path.parent.mkdir(exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            try:
                json.dump(rules, handle, ensure_ascii=False, indent=2)
                handle.write('\n')
                handle.flush()
                os.fsync(handle.fileno())
                os.replace(temporary, path)
            finally:
                temporary.unlink(missing_ok=True)


def active_categories(rules):
    return [item for item in rules['categories'] if item.get('enabled', True)]


def is_generated(path: Path, rules: dict) -> bool:
    return any(re.search(pattern, path.name, re.I) for pattern in rules["generated_name_patterns"])


def is_excluded(relative: Path, rules: dict) -> bool:
    relative_text = relative.as_posix()
    for pattern in rules["excluded_paths"]:
        # Path.match supports ** and keeps the policy readable for non-developers.
        if relative.match(pattern) or relative_text == pattern.rstrip("/**"):
            return True
    return False


def bank_evidence(source: Path | None) -> tuple[bool, str]:
    """Bounded, data-only reads; never execute workbook formulas/macros."""
    if source is None:
        return False, "bank content verification required"
    try:
        if source.is_symlink() or source.stat().st_size > 10 * 1024 * 1024:
            return False, "bank verification skipped: symlink or file exceeds 10 MB"
        cells = []
        if source.suffix.lower() == ".xls":
            import xlrd
            book = xlrd.open_workbook(str(source), on_demand=True)
            try:
                for sheet_index in range(min(book.nsheets, 3)):
                    sheet = book.sheet_by_index(sheet_index)
                    for row in range(min(sheet.nrows, 100)):
                        cells.extend(str(sheet.cell_value(row, col)) for col in range(min(sheet.ncols, 30)))
            finally:
                book.release_resources()
        elif source.suffix.lower() == ".xlsx":
            with zipfile.ZipFile(source) as archive:
                names = [n for n in archive.namelist() if n == "xl/sharedStrings.xml" or re.match(r"xl/worksheets/sheet[1-3]\.xml$", n)]
                if sum(archive.getinfo(n).file_size for n in names) > 5 * 1024 * 1024:
                    return False, "bank verification skipped: expanded workbook exceeds 5 MB"
                for name in names:
                    data = archive.read(name)
                    if b"<!DOCTYPE" in data or b"<!ENTITY" in data:
                        return False, "bank verification rejected unsafe XML"
                    cells.extend(ET.fromstring(data).itertext())
        else:
            return False, "bank verification requires XLS/XLSX"
        text = " ".join(cells).casefold().replace("đ", "d")
        text = "".join(c for c in unicodedata.normalize("NFD", text) if not unicodedata.combining(c))
        bank = re.search(r"vietinbank|vietcombank|techcombank|\bacb\b|\bbidv\b|ngan hang", text)
        account = re.search(r"so tai khoan|account number|account no|tai khoan", text)
        balance = re.search(r"so du|balance|ghi no|ghi co|debit|credit", text)
        return bool(bank and account and balance), "verified bank/account/balance headers" if bank and account and balance else "bank headers not confirmed; review required"
    except Exception as error:
        return False, f"bank verification unavailable ({type(error).__name__}); review required"


def classify(relative: Path, rules: dict, source: Path | None = None) -> tuple[str, float, str, str | None, str]:
    text = normalized(relative.as_posix())
    categories = {item["id"]: item for item in active_categories(rules)}
    # Explicit filing location wins over incidental words in the filename.
    folders = {**FOLDER_CATEGORIES, **{category['target']: category['id'] for category in reversed(tuple(categories.values()))}}
    for folder, category_id in sorted(folders.items(), key=lambda item: len(item[0]), reverse=True):
        if within(relative.as_posix(), folder) and category_id in categories:
            category = categories[category_id]
            mode = category.get("route_mode", "review_only") if folder in REPORT_TARGETS.values() else "review_only"
            return category_id, float(category["confidence"]), f"folder: {folder}", folder, mode
    if 'commerce' in categories and re.search(r"\bb2b\b", text):
        if re.search(r"b[aả]ng gi[aá]", text):
            return "commerce", 0.94, "B2B price list; review required", B2B_PRICES, "review_only"
        if re.search(r"(?:d[oố]i so[aá]t|c[oô]ng n[oợ])", text):
            return "commerce", 0.94, "B2B reconciliation; review required", B2B_RECONCILIATION, "review_only"
    for category in categories.values():
        matched = [pattern for pattern in category["patterns"] if re.search(pattern, text, re.I)]
        if matched:
            route_mode = 'managed_move' if category.get('route_mode') == 'managed_move' else 'review_only'
            if category["id"] == "bank_statements" and re.match(r"(?:danh sach giao dich|lich-su-giao-dich)", normalized(relative.name)):
                valid, detail = bank_evidence(source)
                if not valid:
                    return category["id"], 0.5, detail, category["target"], "review_only"
            reason = f"rule: {matched[0]}"
            if category["id"] == "bank_statements" and source is not None and re.match(r"(?:danh sach giao dich|lich-su-giao-dich)", normalized(relative.name)):
                reason += "; verified bank/account/balance headers"
            return category["id"], float(category["confidence"]), reason, category["target"], route_mode
    return "needs_review", 0.0, "no deterministic rule matched", None, "review_only"


def extract_period(name: str, modified_at: int) -> str:
    match = re.search(r"(20\d{2})[-._]?(0[1-9]|1[0-2])(?:[-._]?\d{2})?", name)
    if match:
        return f"{match.group(1)}-{match.group(2)}"
    return dt.datetime.fromtimestamp(modified_at).strftime("%Y-%m")


def dossier_for(category: str, relative: Path, modified_at: int) -> str:
    basename = normalized(relative.name)
    if category == "needs_review":
        subject = re.sub(r"[^a-z0-9]+", "-", normalized(relative.stem)).strip("-")[:32] or "document"
    elif "ghtk" in basename:
        subject = "ghtk"
    elif basename.startswith("order."):
        subject = "orders"
    elif "doi soat" in basename or "đối soát" in relative.name.casefold():
        subject = "reconciliation"
    elif "label" in basename:
        subject = "labels"
    elif "shopee" in basename:
        subject = "shopee"
    else:
        subject = normalized(relative.parts[0] if len(relative.parts) > 1 else "root")
        subject = re.sub(r"[^a-z0-9]+", "-", subject).strip("-")[:32] or "general"
    return f"{category.upper()}-{extract_period(relative.name, modified_at)}-{subject.upper()}"


def files_for_scan(year_root: Path, scopes: Iterable[Path], root_files: bool, rules: dict) -> Iterable[Path]:
    seen: set[Path] = set()
    if root_files:
        for entry in year_root.iterdir():
            if entry.is_file():
                seen.add(entry)
    for scope in scopes:
        if not scope.exists():
            continue
        if scope.is_file():
            seen.add(scope)
        else:
            for entry in scope.rglob("*"):
                if entry.is_file():
                    seen.add(entry)
    for entry in sorted(seen):
        relative = entry.relative_to(year_root)
        if not entry.is_symlink() and entry.resolve().is_relative_to(year_root.resolve()) and not is_excluded(relative, rules) and not is_generated(entry, rules):
            yield entry


def mark_scopes_inactive(conn: sqlite3.Connection, year_root: Path, scopes: Iterable[Path], root_files: bool) -> None:
    """Reconcile only the requested scope, preserving documents from other scans."""
    if root_files:
        conn.execute("UPDATE documents SET active = 0 WHERE instr(path, '/') = 0")
    for scope in scopes:
        if scope == year_root:
            conn.execute("UPDATE documents SET active = 0")
            continue
        try:
            relative = scope.relative_to(year_root).as_posix()
        except ValueError:
            continue
        conn.execute("UPDATE documents SET active = 0 WHERE path = ? OR path LIKE ?", (relative, relative + "/%"))


def scan(year_root: Path, source_names: list[str], root_files: bool) -> dict[str, int]:
    database, _ = ensure_state(year_root)
    rules = load_rules(year_root)
    sources = [year_root / name for name in (source_names or list(DEFAULT_SCOPES))]
    now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    counters: Counter[str] = Counter()
    with open_db(database) as conn:
        mark_scopes_inactive(conn, year_root, sources, root_files)
        conn.execute("UPDATE documents SET active=0 WHERE path LIKE '.docsync/%'")
        if not source_names:
            for indexed in conn.execute("SELECT path FROM documents WHERE active=1").fetchall():
                if not (year_root / indexed["path"]).is_file():
                    conn.execute("UPDATE documents SET active=0 WHERE path=?", (indexed["path"],))
        for path in files_for_scan(year_root, sources, root_files, rules):
            stat = path.stat()
            relative = path.relative_to(year_root)
            prior = conn.execute("SELECT * FROM documents WHERE path = ?", (relative.as_posix(),)).fetchone()
            sha = prior["sha256"] if prior and prior["byte_size"] == stat.st_size and prior["modified_at"] == stat.st_mtime_ns else digest(path)
            category, confidence, reason, target, _route_mode = classify(relative, rules, path)
            manual = prior and prior["classification_reason"].startswith("manual review:") and prior["sha256"] == sha
            if manual:
                category, confidence, reason, target = prior["category"], prior["confidence"], prior["classification_reason"], prior["proposed_target"]
            dossier_id = prior["dossier_id"] if prior and prior["sha256"] == sha else dossier_for(category, relative, stat.st_mtime)
            status = prior["status"] if prior and prior["sha256"] == sha and prior["status"] not in {"captured", "auto_classified", "needs_review"} else ("auto_classified" if confidence >= 0.85 else "needs_review")
            conn.execute(
                """INSERT INTO documents(path, sha256, byte_size, modified_at, observed_at, category, confidence, classification_reason, proposed_target, dossier_id, status, active)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                   ON CONFLICT(path) DO UPDATE SET sha256=excluded.sha256, byte_size=excluded.byte_size,
                     modified_at=excluded.modified_at, observed_at=excluded.observed_at, category=excluded.category,
                     confidence=excluded.confidence, classification_reason=excluded.classification_reason,
                     proposed_target=excluded.proposed_target, dossier_id=excluded.dossier_id, status=excluded.status, active=1""",
                (relative.as_posix(), sha, stat.st_size, stat.st_mtime_ns, now, category, confidence, reason, target, dossier_id, status),
            )
            conn.execute(
                """INSERT INTO dossiers(dossier_id, category, status, proposed_target, updated_at) VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(dossier_id) DO UPDATE SET category=excluded.category, proposed_target=excluded.proposed_target, updated_at=excluded.updated_at""",
                (dossier_id, category, status, target, now),
            )
            counters[category] += 1
        conn.execute("INSERT INTO events(created_at, event_type, subject, detail) VALUES (?, 'scan', 'documents', ?)", (now, json.dumps(dict(counters), ensure_ascii=False)))
    return dict(counters)


def set_dossier_status(year_root: Path, dossier_id: str, status: str) -> None:
    if status not in VALID_STATUSES:
        raise ValueError(f"invalid status: {status}")
    database, _ = ensure_state(year_root)
    now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    with open_db(database) as conn:
        found = conn.execute("SELECT 1 FROM dossiers WHERE dossier_id = ?", (dossier_id,)).fetchone()
        if not found:
            raise ValueError(f"dossier not found: {dossier_id}")
        conn.execute("UPDATE dossiers SET status = ?, updated_at = ? WHERE dossier_id = ?", (status, now, dossier_id))
        conn.execute("UPDATE documents SET status = ? WHERE dossier_id = ? AND active = 1", (status, dossier_id))
        conn.execute("INSERT INTO events(created_at, event_type, subject, detail) VALUES (?, 'status_change', ?, ?)", (now, dossier_id, status))


def review_dossier(year_root: Path, dossier_id: str, category: str, target: str | None, status: str, note: str) -> None:
    """Record a human routing decision in the index without touching source files."""
    if status not in VALID_STATUSES or status in {"captured", "auto_classified", "needs_review"}:
        raise ValueError("review status must be in_progress, waiting_external, approved, filed, or archived")
    database, _ = ensure_state(year_root)
    categories = {item["id"]: item for item in load_rules(year_root)["categories"]}
    if category not in categories:
        raise ValueError(f"unknown category: {category}")
    proposed_target = target if target is not None else categories[category]["target"]
    now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    with open_db(database) as conn:
        found = conn.execute("SELECT 1 FROM dossiers WHERE dossier_id = ?", (dossier_id,)).fetchone()
        if not found:
            raise ValueError(f"dossier not found: {dossier_id}")
        conn.execute(
            "UPDATE dossiers SET category = ?, status = ?, proposed_target = ?, updated_at = ? WHERE dossier_id = ?",
            (category, status, proposed_target, now, dossier_id),
        )
        conn.execute(
            """UPDATE documents SET category = ?, confidence = 1.0, classification_reason = ?,
               proposed_target = ?, status = ? WHERE dossier_id = ? AND active = 1""",
            (category, f"manual review: {note or 'routing decision'}", proposed_target, status, dossier_id),
        )
        detail = json.dumps({"category": category, "target": proposed_target, "status": status, "note": note}, ensure_ascii=False)
        conn.execute("INSERT INTO events(created_at, event_type, subject, detail) VALUES (?, 'manual_review', ?, ?)", (now, dossier_id, detail))


def route_file(rules_file: Path, relative_path: str, source: Path | None = None, *, scope: Path | None = None) -> tuple[str, float, str | None, str, str]:
    """Classify a single path against an explicit rules file; makes no file changes."""
    with rules_file.open(encoding="utf-8") as handle:
        rules = migrate_rules(json.load(handle))[0]
    relative = Path(relative_path)
    if is_excluded(scope or relative, rules) or is_generated(relative, rules):
        return 'needs_review', 0, None, 'review_only', 'excluded by settings'
    category, confidence, reason, target, route_mode = classify(relative, rules, source)
    return category, confidence, target, route_mode, reason


def review_queue(year_root: Path) -> list[sqlite3.Row]:
    database, _ = ensure_state(year_root)
    with open_db(database) as conn:
        return conn.execute(
            """SELECT dossier_id, path, classification_reason FROM documents
               WHERE active = 1 AND status = 'needs_review' ORDER BY path"""
        ).fetchall()


def next_action(status: str) -> str:
    actions = {
        "captured": "Run classification scan.",
        "auto_classified": "Check target and evidence, then start work or request a correction.",
        "needs_review": "Choose category and destination with the review command.",
        "in_progress": "Complete the dossier checklist and resolve missing evidence.",
        "waiting_external": "Follow up with the external owner and record the response.",
        "approved": "Ready for a future copy-and-hash filing step; filing is not enabled.",
        "filed": "Verify final location and archive the dossier when retention allows.",
        "archived": "No further action.",
    }
    return actions.get(status, "Review dossier status.")


def dashboard(year_root: Path, output: Path | None = None) -> Path:
    database, _ = ensure_state(year_root)
    output = output or state_dir(year_root) / "dashboard.html"
    labels_by_category = {item["id"]: item["label"] for item in load_rules(year_root)["categories"]}
    labels_by_category["needs_review"] = "Needs review"
    with open_db(database) as conn:
        rows = conn.execute(
            """SELECT d.dossier_id, d.category, d.status, d.proposed_target, d.updated_at, COUNT(doc.path) AS document_count,
                      MIN(doc.confidence) AS confidence, GROUP_CONCAT(doc.path, '||') AS paths,
                      GROUP_CONCAT(DISTINCT doc.classification_reason) AS reasons
                 FROM dossiers d JOIN documents doc ON doc.dossier_id = d.dossier_id
                 WHERE doc.active = 1 GROUP BY d.dossier_id ORDER BY d.updated_at DESC"""
        ).fetchall()
    rows = [dict(row) for row in rows]
    if year_root.resolve() == work_root().resolve():
        from docsync_topics import REVIEW_FILE, cached_fingerprint
        runtime = Path(os.environ.get('STATE_DIR', str(TOOL_ROOT / 'ivar-documents-organizer')))
        index = runtime / REVIEW_FILE
        decisions = json.loads(index.read_text()) if index.exists() else {}
        for relative, decision in decisions.items():
            source = year_root / relative
            if decision.get('status') not in ('pending', 'held') or not source.exists():
                continue
            try:
                if cached_fingerprint(source, decision) != decision['sha256']:
                    continue
            except ValueError:
                continue
            for row in rows:
                if any(within(path, relative) for path in (row['paths'] or '').split('||')):
                    row['status'] = 'waiting_external' if decision['status'] == 'pending' else 'needs_review'
                    row['reasons'] = 'Đã gửi Telegram; chờ chọn chủ đề' if decision['status'] == 'pending' else 'Đã chọn giữ lại qua Telegram'
                    row['next_action'] = 'Trả lời /ds trong bot Telegram để chọn chủ đề hoặc giữ lại.' if decision['status'] == 'pending' else 'Giữ nguyên theo quyết định của bạn.'

    by_status: dict[str, list[sqlite3.Row]] = {status: [] for status in VALID_STATUSES}
    for row in rows:
        by_status.setdefault(row["status"], []).append(row)
    columns = ["captured", "auto_classified", "needs_review", "in_progress", "waiting_external", "approved", "filed"]
    labels = {"captured": "Captured", "auto_classified": "Auto-classified", "needs_review": "Needs review", "in_progress": "In progress", "waiting_external": "Waiting external", "approved": "Approved", "filed": "Filed"}
    board = []
    for status in columns:
        cards = []
        for row in by_status[status]:
            paths = (row["paths"] or "").split("||")
            preview = "<br>".join(html.escape(path) for path in paths[:3])
            extra = f"<div class='more'>+{len(paths)-3} files</div>" if len(paths) > 3 else ""
            target = html.escape(row["proposed_target"] or "No target proposed")
            category_label = html.escape(labels_by_category.get(row["category"], row["category"]))
            confidence = f"{float(row['confidence']) * 100:.0f}% confidence"
            reasons = html.escape(row["reasons"] or "No evidence recorded")
            action = html.escape(row.get('next_action') or next_action(status))
            cards.append(f"<article class='card'><h3>{html.escape(row['dossier_id'])}</h3><p class='category'>{category_label} · {row['document_count']} files · {confidence}</p><p class='target'>{target}</p><p class='action'><strong>Next:</strong> {action}</p><p class='evidence'><strong>Evidence:</strong> {reasons}</p><p class='paths'>{preview}</p>{extra}</article>")
        board.append(f"<section class='column'><header><h2>{labels[status]}</h2><span>{len(by_status[status])}</span></header>{''.join(cards) or '<p class=empty>No dossier</p>'}</section>")
    total = sum(row["document_count"] for row in rows)
    output.write_text(f"""<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>WIP &amp; Reference · Kanban</title><style>
*{{box-sizing:border-box}}body{{margin:0;background:#f6f7fb;color:#1c1b20;font:14px/1.45 Arial,sans-serif}}main{{padding:24px;max-width:2200px;margin:auto}}h1{{margin:0;font-size:28px}}.subtitle{{color:#5f6368}}.board{{display:grid;grid-template-columns:repeat(7,minmax(265px,1fr));gap:16px;overflow-x:auto;padding:8px 0 20px}}.column{{background:#eef0f7;border-radius:16px;padding:12px;min-height:280px}}.column header{{display:flex;align-items:center;justify-content:space-between;margin:2px 4px 12px}}.column h2{{font-size:15px;margin:0}}.column header span{{background:#d9e2ff;color:#17386d;border-radius:999px;padding:2px 9px;font-weight:bold}}.card{{background:#fff;border-radius:12px;padding:13px;margin:10px 0;box-shadow:0 1px 3px #0002;border-left:4px solid #4f73c7}}.card h3{{font-size:13px;margin:0 0 6px;overflow-wrap:anywhere}}.category{{color:#4a5568;margin:0 0 8px;text-transform:capitalize}}.target{{background:#eef4ff;color:#174ea6;margin:0 -2px 9px;padding:5px 7px;border-radius:6px;overflow-wrap:anywhere}}.action{{background:#f4f7f8;margin:0 -2px 8px;padding:6px 7px;border-radius:6px}}.evidence{{color:#4a5568;font-size:12px;margin:0 0 8px;overflow-wrap:anywhere}}.paths{{color:#5f6368;font-size:12px;margin:0;overflow-wrap:anywhere}}.more,.empty{{color:#697386;font-style:italic}}@media(max-width:700px){{main{{padding:16px}}.board{{grid-template-columns:repeat(7,84vw)}}}}</style>
<main><h1>WIP &amp; Reference · Kanban</h1><p class='subtitle'>{len(rows)} dossiers · {total} active documents · Work topics organize files; columns show the next workflow step. Uncertain decisions go to Telegram.</p><div class='board'>{''.join(board)}</div></main>""", encoding="utf-8")
    return output


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--root", "--year-root", dest="year_root", type=Path, default=YEAR_ROOT, help="defaults to Documents/WIP & Reference")
    sub = result.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="Create empty WIP folders, state database and editable rules.json")
    scan_parser = sub.add_parser("scan", help="Index files only; never moves, renames, copies or deletes")
    scan_parser.add_argument("--source", action="append", default=[], help="relative folder or file to index; repeatable")
    scan_parser.add_argument("--no-root-files", action="store_true", help="do not include loose files directly under the work root")
    dash = sub.add_parser("dashboard", help="Render a static Material-style Kanban HTML page")
    dash.add_argument("--output", type=Path)
    status = sub.add_parser("set-status", help="Update a dossier status in the index; does not touch documents")
    status.add_argument("dossier_id")
    status.add_argument("status", choices=VALID_STATUSES)
    review = sub.add_parser("review", help="Record a human category and target decision; does not touch documents")
    review.add_argument("dossier_id")
    review.add_argument("category", help="category id from rules.json")
    review.add_argument("--target", help="override the category's proposed target")
    review.add_argument("--status", choices=("in_progress", "waiting_external", "approved", "filed", "archived"), default="in_progress")
    review.add_argument("--note", default="", help="short reason recorded in the local audit log")
    sub.add_parser("review-queue", help="List dossiers still requiring a human routing decision")
    check_target = sub.add_parser("check-target", help="Validate an automatic target without changing files")
    check_target.add_argument("--target", required=True)
    route = sub.add_parser("route", help="Classify one path against a rules file; makes no file changes")
    route.add_argument("--rules", type=Path, required=True, help="path to a rules.json file")
    route.add_argument("--path", required=True, help="relative path or filename to classify")
    route.add_argument("--source", type=Path, help="source workbook for bank header verification")
    route.add_argument("--format", choices=("tsv",), default="tsv")
    return result


ROUTE_NOT_APPROVED = 3


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if args.command == "check-target":
        rules = load_rules(args.year_root)
        allowed = any(item['target'] == args.target and item.get('route_mode') == 'managed_move'
                      for item in active_categories(rules))
        return 0 if allowed and approved_target(args.year_root, args.target, configured=True) else ROUTE_NOT_APPROVED
    if args.command == "route":
        scope = args.source.relative_to(args.year_root) if args.source and args.source.is_relative_to(args.year_root) else None
        category, confidence, target, route_mode, reason = route_file(args.rules, args.path, args.source, scope=scope)
        print("\t".join([category, f"{confidence:g}", target or "", route_mode, reason]))
        return 0 if (route_mode == "managed_move" and target) else ROUTE_NOT_APPROVED
    year_root = args.year_root.resolve()
    if not year_root.is_dir():
        raise SystemExit(f"Year root does not exist: {year_root}")
    if args.command == "init":
        database, rule_file = ensure_state(year_root)
        print(f"Initialized {state_dir(year_root)}\nRules: {rule_file}\nDatabase: {database}")
    elif args.command == "scan":
        counters = scan(year_root, args.source, not args.no_root_files)
        print("Indexed (no files moved): " + ", ".join(f"{key}={value}" for key, value in sorted(counters.items())))
    elif args.command == "dashboard":
        print(dashboard(year_root, args.output))
    elif args.command == "set-status":
        set_dossier_status(year_root, args.dossier_id, args.status)
        print(f"Updated {args.dossier_id} to {args.status}; no files changed.")
    elif args.command == "review":
        review_dossier(year_root, args.dossier_id, args.category, args.target, args.status, args.note)
        print(f"Recorded manual review for {args.dossier_id}; no files changed.")
    elif args.command == "review-queue":
        for row in review_queue(year_root):
            print(f"{row['dossier_id']}\t{row['path']}\t{row['classification_reason']}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, sqlite3.Error, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
